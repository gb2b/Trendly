jQuery(document).ready(function($) {
	//Initiation d"un objet storage pour la gestion du localstorage
	storage.init();
	//Récupération ds données sous forme d'un tableau dans le localstorage
	var datas = storage.render();
	//Récupération des templates dans la page php
	var templateUpTrend = $('#trendUpTlp').html();
	var templateTrend   = $('#trendTlp').html();
	var colors          = ["flat-red", "flat-green", "flat-blue", "flat-yellow"];
	var colori          = 0;
	//Parcours des différentes lignes du localstorage 
	for (var i = 0; i < datas.length; i++) {
		var inner = "inner"+i;
		var data = JSON.parse(datas[i]);
		//Ajout des données dans les templates via mustache, puis insertion dans la page
		var html = Mustache.to_html(templateUpTrend, data[0]);
		$('.content').append(html);
		//Réglages de détails d'affichage
		$('article').eq(i).find('input').attr('id', inner);
		$('article').eq(i).find('label').attr('for', inner);
		$('.dropdown-btn').eq(i).addClass(colors[colori]);
		//Parcours des différentes valeur de la ligne correspondante du localstorage
		for (var j = 0; j < data.length; j++) {
			var html2 = Mustache.to_html(templateTrend, data[j]);
			$('.inner').eq(i).append(html2);
		}
		if (colori>3) {
			colori = 0;
		}else{
			colori++;
		}
	}
	//Lors du click sur un lien de classe .delete-btn, la ligne du localstorage est supprimée et cela nous est retournée visuellement
	$('body').on('click', '.delete-btn', function(event) {
		event.preventDefault();
		storage.deleteKey($(this).data('trend'));
		$(this).parent("article").remove();
	});
	//Lors du click sur la lien de span.delete, la valeur de la ligne du tableau correspondante est supprimée et cela nous est retourné visuellement
	$('body').on('click', 'span.delete', function(event) {
		event.preventDefault();
		if (storage.deleteValueOfKey($(this).data('trend'), parseInt($(this).data('key')))) {
			$(this).parent().parent().parent().parent("article").remove();			
		}else{
			$(this).parent().parent(".inner-content").remove();
		}

	});
});
